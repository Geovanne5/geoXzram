#!/system/bin/sh

#changing zram compression

echo lz4 > /sys/block/zram0/comp_algorithm